import React from 'react';
import { Link } from './Link';
import { Wrench, Phone, Calendar } from 'lucide-react';

export function Header() {
  return (
    <header className="bg-white shadow-md">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex items-center">
            <Wrench className="h-8 w-8 text-blue-600" />
            <span className="ml-2 text-xl font-bold text-gray-900">PR Auto Solutions</span>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <Link href="/">Home</Link>
            <Link href="/services">Services</Link>
            <Link href="/about">About</Link>
            <Link href="/blog">Blog</Link>
            <Link href="/contact">Contact</Link>
          </div>

          <div className="flex items-center space-x-4">
            <a href="tel:+1234567890" className="flex items-center text-blue-600 hover:text-blue-700">
              <Phone className="h-5 w-5 mr-1" />
              <span className="hidden sm:inline">(123) 456-7890</span>
            </a>
            <button className="bg-blue-600 text-white px-4 py-2 rounded-md flex items-center hover:bg-blue-700 transition">
              <Calendar className="h-5 w-5 mr-2" />
              Book Now
            </button>
          </div>
        </div>
      </nav>
    </header>
  );
}