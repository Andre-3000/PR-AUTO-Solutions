import React from 'react';
import { ArrowRight } from 'lucide-react';

export function Hero() {
  return (
    <div className="relative bg-gray-900">
      <div className="absolute inset-0">
        <img
          className="w-full h-full object-cover opacity-30"
          src="https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&q=80"
          alt="Auto mechanic workshop"
        />
      </div>
      
      <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl lg:text-6xl">
          Expert Auto Care You Can Trust
        </h1>
        <p className="mt-6 text-xl text-gray-300 max-w-3xl">
          Professional diagnostics, repairs, and maintenance services to keep your vehicle running at its best. Experience the PR Auto Solutions difference.
        </p>
        <div className="mt-10 flex items-center gap-x-6">
          <button className="bg-blue-600 text-white px-8 py-3 rounded-md flex items-center hover:bg-blue-700 transition">
            Book Service
            <ArrowRight className="ml-2 h-5 w-5" />
          </button>
          <button className="text-white font-semibold hover:text-blue-400 transition">
            View Services
            <ArrowRight className="ml-2 h-5 w-5 inline" />
          </button>
        </div>
      </div>
    </div>
  );
}